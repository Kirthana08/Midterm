class Student{
    public Student() {
        System.out.println("Student details");
    } 
    
}

class Name extends Student{
    public Name(){
        System.out.println("Name: ");
    }
    public void name(){
        System.out.print("Amin");
    }
}

class Address extends Name{
    public Address(){
        System.out.println("Address: ");
    }
    public void address(){
        System.out.print("75 Kg Ramal Luar, 43000, Kajang, Selangor ");
    }
}

class birthDate extends Address{
    public birthDate(){
        System.out.println("Date of Birth: ");
    }
    public void dob(){
        System.out.print("11th August 1996");
    }


public static void main (String args[]){
    birthDate obj = new birthDate();
    obj.address();
    obj.dob();
}

}

